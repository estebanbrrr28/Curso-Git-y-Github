package com.sena.java_web2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaWeb2Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaWeb2Application.class, args);
	}

}
