package com.sena.java_web2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaWeb2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
